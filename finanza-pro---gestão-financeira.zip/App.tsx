
import React, { useState, useEffect } from 'react';
import Sidebar from './components/Sidebar';
import Dashboard from './components/Dashboard';
import TransactionsList from './components/TransactionsList';
import InvestmentsBoard from './components/InvestmentsBoard';
import CreditCardsManager from './components/CreditCardsManager';
import BankAccountsManager from './components/BankAccountsManager';
import AIAdvisor from './components/AIAdvisor';
import { View, Transaction, TransactionType, BankAccount, Category, AppNotification, Investment, CreditCard } from './types';
import { INITIAL_TRANSACTIONS, INITIAL_INVESTMENTS, INITIAL_CARDS, INITIAL_BANK_ACCOUNTS, INITIAL_CATEGORIES } from './constants';
import { X, Bell, Info, AlertTriangle } from 'lucide-react';

const App: React.FC = () => {
  const [currentView, setCurrentView] = useState<View>('dashboard');
  const [transactions, setTransactions] = useState<Transaction[]>(INITIAL_TRANSACTIONS);
  const [bankAccounts, setBankAccounts] = useState<BankAccount[]>(INITIAL_BANK_ACCOUNTS);
  const [categories, setCategories] = useState<Category[]>(INITIAL_CATEGORIES);
  const [investments, setInvestments] = useState<Investment[]>(INITIAL_INVESTMENTS);
  const [cards, setCards] = useState<CreditCard[]>(INITIAL_CARDS);
  const [notifications, setNotifications] = useState<AppNotification[]>([]);
  const [showNotificationCenter, setShowNotificationCenter] = useState(false);

  useEffect(() => {
    checkUpcomingPayments();
  }, [transactions, cards]);

  const checkUpcomingPayments = () => {
    const alerts: AppNotification[] = [];
    const today = new Date();
    const currentDay = today.getDate();

    // Check Credit Cards
    cards.forEach(card => {
      const due = parseInt(card.dueDate);
      const diff = due - currentDay;
      if (diff >= 0 && diff <= 3) {
        alerts.push({
          id: `card-${card.id}-${today.getTime()}`,
          title: `Vencimento Próximo: ${card.name}`,
          message: `Sua fatura de R$ ${card.used.toLocaleString()} vence em ${diff === 0 ? 'hoje' : diff + ' dias'}.`,
          type: 'warning',
          date: new Date(),
          read: false
        });
      }
    });

    // Check Upcoming Expense Transactions (Scheduled or Future)
    transactions.filter(t => t.type === TransactionType.EXPENSE).forEach(t => {
      const txDate = new Date(t.date);
      const diffTime = txDate.getTime() - today.getTime();
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
      
      if (diffDays >= 0 && diffDays <= 3) {
        alerts.push({
          id: `tx-${t.id}-${today.getTime()}`,
          title: `Conta a pagar: ${t.description}`,
          message: `Pagamento de R$ ${t.amount.toLocaleString()} agendado para ${diffDays === 0 ? 'hoje' : 'daqui a ' + diffDays + ' dias'}.`,
          type: 'info',
          date: new Date(),
          read: false
        });
      }
    });

    setNotifications(alerts);
  };

  const markAsRead = (id: string) => {
    setNotifications(prev => prev.map(n => n.id === id ? { ...n, read: true } : n));
  };

  const handleAddTransaction = (newTx: Omit<Transaction, 'id'>) => {
    const transaction: Transaction = { ...newTx, id: Math.random().toString(36).substr(2, 9) };
    setTransactions(prev => [transaction, ...prev]);
  };

  const handleUpdateTransaction = (updatedTx: Transaction) => {
    setTransactions(prev => prev.map(t => t.id === updatedTx.id ? updatedTx : t));
  };

  const handleDeleteTransaction = (id: string) => {
    setTransactions(prev => prev.filter(t => t.id !== id));
  };

  const handleAddCategory = (name: string, type: TransactionType, color: string) => {
    setCategories(prev => [...prev, { id: Math.random().toString(36).substr(2, 9), name, type, color }]);
  };

  const handleUpdateCategory = (updatedCat: Category) => {
    setCategories(prev => prev.map(c => c.id === updatedCat.id ? updatedCat : c));
  };

  const handleDeleteCategory = (id: string) => {
    setCategories(prev => prev.filter(c => c.id !== id));
  };

  const handleAddBankAccount = (acc: BankAccount) => {
    setBankAccounts(prev => [...prev, acc]);
  };

  const handleUpdateBankAccount = (updatedAcc: BankAccount) => {
    setBankAccounts(prev => prev.map(acc => acc.id === updatedAcc.id ? updatedAcc : acc));
  };

  const handleDeleteBankAccount = (id: string) => {
    setBankAccounts(prev => prev.filter(acc => acc.id !== id));
    // Also remove link from cards
    setCards(prev => prev.map(card => card.bankAccountId === id ? { ...card, bankAccountId: undefined } : card));
  };

  const handleAddInvestment = (newInv: Omit<Investment, 'id'>) => {
    setInvestments(prev => [...prev, { ...newInv, id: Math.random().toString(36).substr(2, 9) }]);
  };

  const handleUpdateInvestment = (updatedInv: Investment) => {
    setInvestments(prev => prev.map(inv => inv.id === updatedInv.id ? updatedInv : inv));
  };

  const handleDeleteInvestment = (id: string) => {
    setInvestments(prev => prev.filter(inv => inv.id !== id));
  };

  const handleAddCard = (card: CreditCard) => {
    setCards(prev => [...prev, card]);
  };

  const handleUpdateCard = (updatedCard: CreditCard) => {
    setCards(prev => prev.map(c => c.id === updatedCard.id ? updatedCard : c));
  };

  const handleDeleteCard = (id: string) => {
    setCards(prev => prev.filter(c => c.id !== id));
  };

  const renderContent = () => {
    switch (currentView) {
      case 'dashboard':
        return <Dashboard transactions={transactions} investments={investments} cards={cards} />;
      case 'bank-accounts':
        return <BankAccountsManager accounts={bankAccounts} transactions={transactions} onAdd={handleAddBankAccount} onUpdate={handleUpdateBankAccount} onDelete={handleDeleteBankAccount} />;
      case 'income':
        return <TransactionsList type={TransactionType.INCOME} transactions={transactions} bankAccounts={bankAccounts} categories={categories} onAdd={handleAddTransaction} onUpdate={handleUpdateTransaction} onDelete={handleDeleteTransaction} onAddCategory={handleAddCategory} onUpdateCategory={handleUpdateCategory} onDeleteCategory={handleDeleteCategory} />;
      case 'expenses':
        return <TransactionsList type={TransactionType.EXPENSE} transactions={transactions} bankAccounts={bankAccounts} categories={categories} onAdd={handleAddTransaction} onUpdate={handleUpdateTransaction} onDelete={handleDeleteTransaction} onAddCategory={handleAddCategory} onUpdateCategory={handleUpdateCategory} onDeleteCategory={handleDeleteCategory} />;
      case 'investments':
        return <InvestmentsBoard investments={investments} onAdd={handleAddInvestment} onUpdate={handleUpdateInvestment} onDelete={handleDeleteInvestment} />;
      case 'credit-cards':
        return <CreditCardsManager cards={cards} bankAccounts={bankAccounts} onAdd={handleAddCard} onUpdate={handleUpdateCard} onDelete={handleDeleteCard} />;
      case 'ai-advisor':
        return <AIAdvisor transactions={transactions} investments={investments} cards={cards} />;
      default:
        return <Dashboard transactions={transactions} investments={investments} cards={cards} />;
    }
  };

  return (
    <div className="flex h-screen overflow-hidden bg-slate-50">
      <Sidebar 
        currentView={currentView} 
        setCurrentView={setCurrentView} 
        notifications={notifications}
        onShowNotifications={() => setShowNotificationCenter(true)}
      />
      <main className="flex-1 overflow-y-auto p-4 md:p-8 lg:p-12 relative">
        <div className="absolute top-0 right-0 w-64 h-64 bg-emerald-500/5 blur-[100px] pointer-events-none rounded-full" />
        <div className="absolute bottom-0 left-0 w-96 h-96 bg-blue-500/5 blur-[120px] pointer-events-none rounded-full" />
        <div className="max-w-6xl mx-auto">{renderContent()}</div>
      </main>

      {/* Notification Center UI */}
      {showNotificationCenter && (
        <div className="fixed inset-0 z-[100] bg-black/40 backdrop-blur-sm flex justify-end">
          <div className="w-full max-w-sm bg-white h-full shadow-2xl animate-in slide-in-from-right duration-300 flex flex-col">
            <div className="p-6 border-b border-slate-100 flex items-center justify-between">
              <h3 className="text-xl font-bold text-slate-800 flex items-center gap-2">
                <Bell size={24} className="text-emerald-500" /> Alertas e Notificações
              </h3>
              <button onClick={() => setShowNotificationCenter(false)} className="p-2 hover:bg-slate-100 rounded-full transition-colors">
                <X size={24} />
              </button>
            </div>
            <div className="flex-1 overflow-y-auto p-4 space-y-4">
              {notifications.length > 0 ? (
                notifications.sort((a,b) => b.date.getTime() - a.date.getTime()).map(n => (
                  <div key={n.id} className={`p-4 rounded-2xl border transition-all ${n.read ? 'bg-white border-slate-100 opacity-60' : 'bg-slate-50 border-emerald-100 shadow-sm'}`}>
                    <div className="flex gap-3">
                      <div className={`mt-1 p-2 rounded-lg ${n.type === 'warning' ? 'bg-amber-100 text-amber-600' : 'bg-blue-100 text-blue-600'}`}>
                        {n.type === 'warning' ? <AlertTriangle size={18} /> : <Info size={18} />}
                      </div>
                      <div className="flex-1">
                        <div className="flex justify-between items-start">
                          <p className="font-bold text-slate-800 text-sm">{n.title}</p>
                          {!n.read && <button onClick={() => markAsRead(n.id)} className="text-[10px] text-emerald-600 font-bold uppercase hover:underline">Lido</button>}
                        </div>
                        <p className="text-xs text-slate-500 mt-1">{n.message}</p>
                        <p className="text-[10px] text-slate-400 mt-2">{n.date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</p>
                      </div>
                    </div>
                  </div>
                ))
              ) : (
                <div className="h-full flex flex-col items-center justify-center text-center p-8 text-slate-400">
                  <Bell size={48} className="mb-4 opacity-20" />
                  <p className="font-medium">Tudo em dia!</p>
                  <p className="text-sm">Você não possui notificações importantes no momento.</p>
                </div>
              )}
            </div>
            <div className="p-4 bg-slate-50 border-t border-slate-100">
              <button 
                onClick={() => setShowNotificationCenter(false)}
                className="w-full py-3 bg-slate-900 text-white rounded-xl font-bold hover:bg-slate-800 transition-colors"
              >
                Fechar Centro de Alertas
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default App;
