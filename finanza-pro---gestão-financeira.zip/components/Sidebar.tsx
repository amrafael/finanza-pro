
import React from 'react';
import { LayoutDashboard, ArrowUpCircle, ArrowDownCircle, Wallet, CreditCard, BrainCircuit, Menu, X, Landmark, Bell } from 'lucide-react';
import { View, AppNotification } from '../types';

interface SidebarProps {
  currentView: View;
  setCurrentView: (view: View) => void;
  notifications: AppNotification[];
  onShowNotifications: () => void;
}

const Sidebar: React.FC<SidebarProps> = ({ currentView, setCurrentView, notifications, onShowNotifications }) => {
  const [isOpen, setIsOpen] = React.useState(false);

  const menuItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'bank-accounts', label: 'Contas', icon: Landmark },
    { id: 'income', label: 'Entradas', icon: ArrowUpCircle },
    { id: 'expenses', label: 'Saídas', icon: ArrowDownCircle },
    { id: 'investments', label: 'Investimentos', icon: Wallet },
    { id: 'credit-cards', label: 'Cartões', icon: CreditCard },
    { id: 'ai-advisor', label: 'AI Advisor', icon: BrainCircuit },
  ];

  const unreadCount = notifications.filter(n => !n.read).length;

  const toggleSidebar = () => setIsOpen(!isOpen);

  return (
    <>
      <button 
        onClick={toggleSidebar}
        className="lg:hidden fixed top-4 left-4 z-50 p-2 bg-white rounded-md shadow-md"
      >
        {isOpen ? <X size={24} /> : <Menu size={24} />}
      </button>

      <aside className={`
        fixed inset-y-0 left-0 z-40 w-64 bg-slate-900 text-white transform transition-transform duration-300 ease-in-out
        ${isOpen ? 'translate-x-0' : '-translate-x-full'}
        lg:translate-x-0 lg:static lg:inset-0
      `}>
        <div className="flex flex-col h-full">
          <div className="p-6 flex items-center justify-between">
            <h1 className="text-2xl font-bold text-emerald-400 flex items-center gap-2">
              <Wallet size={28} />
              Finanza Pro
            </h1>
            <button 
              onClick={onShowNotifications}
              className="relative p-2 hover:bg-slate-800 rounded-full text-slate-400 hover:text-white transition-colors"
            >
              <Bell size={20} />
              {unreadCount > 0 && (
                <span className="absolute top-1.5 right-1.5 w-4 h-4 bg-rose-500 text-white text-[10px] flex items-center justify-center rounded-full animate-pulse">
                  {unreadCount}
                </span>
              )}
            </button>
          </div>

          <nav className="flex-1 px-4 space-y-1">
            {menuItems.map((item) => (
              <button
                key={item.id}
                onClick={() => {
                  setCurrentView(item.id as View);
                  setIsOpen(false);
                }}
                className={`
                  w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-colors
                  ${currentView === item.id 
                    ? 'bg-emerald-600 text-white' 
                    : 'text-slate-400 hover:bg-slate-800 hover:text-white'}
                `}
              >
                <item.icon size={20} />
                <span className="font-medium">{item.label}</span>
              </button>
            ))}
          </nav>

          <div className="p-4 border-t border-slate-800">
            <div className="flex items-center gap-3 px-2">
              <div className="w-10 h-10 rounded-full bg-emerald-500/20 flex items-center justify-center text-emerald-400 font-bold">
                JD
              </div>
              <div className="overflow-hidden">
                <p className="text-sm font-medium truncate">João Diniz</p>
                <p className="text-xs text-slate-500 truncate">Plano Premium</p>
              </div>
            </div>
          </div>
        </div>
      </aside>
    </>
  );
};

export default Sidebar;
